<?php

//var_dump($GLOBALS);
var_dump($_FILES);

?>
