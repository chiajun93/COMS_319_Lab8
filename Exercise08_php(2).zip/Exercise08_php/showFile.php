<?php

echo '<div style="font-size:20px;">';
print highlight_file($_GET["name"],true);
echo '</div>';

?>
